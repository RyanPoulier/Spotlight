/**
 * Created by Padmaka on 8/14/16.
 */

var host = "localhost";
var port = "8080";